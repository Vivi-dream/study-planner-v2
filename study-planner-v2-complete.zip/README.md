# STUDY PLANNER V2 🌸

Organise. Révise. Réussis.

## Version actuelle
This version is a complete client-side prototype. Data is stored in the browser with localStorage.

Included:
- Dashboard
- Subjects
- Courses/materials
- Spaced revisions
- Calendar
- Flashcards
- Quizzes
- Lili assistant (local rule-based prototype)
- Focus timer
- XP/streak
- Statistics
- Profile
- Responsive design

## Next phase
Connect the existing data layer to Supabase:
- authentication
- profiles
- matieres
- chapitres
- materiels
- revisions
- quiz/flashcard progress
- RLS policies

Do not put secret API keys in front-end JavaScript.
