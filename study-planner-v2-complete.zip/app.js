const KEY="studyPlannerV2";
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const today=()=>new Date().toISOString().slice(0,10);
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,8);
const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
const days=["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"];
const months=["janvier","février","mars","avril","mai","juin","juillet","août","septembre","octobre","novembre","décembre"];
const subjectIcons=["📐","📖","🇬🇧","🌍","🧪","🌱","🇪🇸","🎨","💻","🎵"];
const colors=["#e9a8bd","#b9a7e8","#8fc9bd","#e8bd7d","#a9bfe8","#d89fca"];

function seed(){
  return {user:null,subjects:[],materials:[],revisions:[],flashcards:[],quizzes:[],xp:0,streak:0,bestStreak:0,lastStudy:null,focusSessions:0};
}
let state=JSON.parse(localStorage.getItem(KEY)||"null")||seed();
function save(){localStorage.setItem(KEY,JSON.stringify(state))}
function toast(msg){const d=document.createElement("div");d.className="toast";d.textContent=msg;$("#toast-container").appendChild(d);setTimeout(()=>d.remove(),2600)}
function show(id){$("#auth-screen").classList.toggle("hidden",id!=="auth");$("#main-app").classList.toggle("hidden",id!=="app")}
function level(){return Math.floor(state.xp/100)+1}
function addXP(n){state.xp+=n;state.lastStudy=today();state.streak=state.lastStudy===today()?Math.max(1,state.streak):state.streak;state.bestStreak=Math.max(state.bestStreak,state.streak);save();renderAll()}
function dateLabel(d){const x=new Date(d+"T12:00:00");return `${String(x.getDate()).padStart(2,"0")}/${String(x.getMonth()+1).padStart(2,"0")}`}
function subjectName(id){return state.subjects.find(s=>s.id===id)?.name||"Matière"}
function materialName(id){return state.materials.find(m=>m.id===id)?.title||"Cours"}
function isDue(r){return !r.completed&&r.date<=today()}
function updateStreak(){
  if(!state.lastStudy)return;
  const diff=Math.round((new Date(today())-new Date(state.lastStudy))/86400000);
  if(diff>1)state.streak=0;
  save();
}
function loginDemo(){
  if(!state.user){state.user={firstName:"Élève",displayName:"Élève",age:14,classLevel:"Seconde",birthdate:"",email:"demo@studyplanner.local",avatar:"🌸"};seedData()}
  show("app");renderAll();
}
function seedData(){
  if(state.subjects.length)return;
  const names=["Mathématiques","Français","Anglais","Histoire-Géo","Physique-Chimie"];
  state.subjects=names.map((name,i)=>({id:uid(),name,icon:subjectIcons[i],color:colors[i],createdAt:today()}));
  const math=state.subjects[0].id, eng=state.subjects[2].id;
  const m1={id:uid(),subjectId:math,title:"Équations du second degré",type:"course",content:"Une équation du second degré s'écrit ax² + bx + c = 0 avec a ≠ 0. On peut utiliser le discriminant Δ = b² - 4ac.",createdAt:today()};
  const m2={id:uid(),subjectId:eng,title:"Advanced vocabulary",type:"notes",content:"Reluctant = réticent. Thorough = approfondi. Scarce = rare / en quantité limitée.",createdAt:today()};
  state.materials=[m1,m2];
  [0,2,5,7].forEach((offset,i)=>{let d=new Date();d.setDate(d.getDate()+offset);state.revisions.push({id:uid(),materialId:i%2?m2.id:m1.id,number:i+1,date:d.toISOString().slice(0,10),completed:false})});
  state.flashcards=[
    {id:uid(),materialId:m1.id,question:"Quelle est la formule du discriminant ?",answer:"Δ = b² - 4ac"},
    {id:uid(),materialId:m1.id,question:"Dans ax² + bx + c = 0, quelle condition doit respecter a ?",answer:"a doit être différent de 0."},
    {id:uid(),materialId:m2.id,question:"Que signifie reluctant ?",answer:"Réticent, peu disposé à faire quelque chose."},
    {id:uid(),materialId:m2.id,question:"Que signifie thorough ?",answer:"Approfondi, minutieux, très complet."}
  ];
  save();
}
function openModal(html){$("#modal-content").innerHTML=html;$("#modal-overlay").classList.remove("hidden")}
function closeModal(){$("#modal-overlay").classList.add("hidden")}
function renderDate(){
  const d=new Date();$("#current-day").textContent=days[d.getDay()];$("#current-date").textContent=`${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
}
function navigate(page){
  $$(".page").forEach(p=>p.classList.add("hidden"));
  const target=$(`#page-${page}`);if(target)target.classList.remove("hidden");
  $$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  renderPage(page);
  $(".sidebar")?.classList.remove("open");
}
function renderPage(page){if(page==="dashboard")renderDashboard();if(page==="subjects")renderSubjects();if(page==="materials")renderMaterials();if(page==="revisions")renderRevisions();if(page==="calendar")renderCalendar();if(page==="flashcards")renderFlashcards();if(page==="quiz")renderQuizOptions();if(page==="statistics")renderStats();if(page==="profile")renderProfile()}
function renderDashboard(){
  updateStreak();const u=state.user||{};$("#dashboard-greeting").textContent=`Bonjour ${u.displayName||u.firstName||"🌸"} 🌸`;
  $("#dashboard-subject-count").textContent=state.subjects.length;$("#dashboard-revision-count").textContent=state.revisions.filter(isDue).length;$("#dashboard-xp").textContent=state.xp;$("#dashboard-streak").textContent=state.streak;
  $("#sidebar-streak").textContent=`${state.streak} ${state.streak>1?"jours":"jour"}`;$("#sidebar-name").textContent=u.displayName||"Élève";$("#sidebar-avatar").textContent=u.avatar||"🌸";
  $("#user-level").textContent=level();$("#level-current-xp").textContent=`${state.xp%100} XP`;$("#level-next-xp").textContent="100";$("#xp-progress-bar").style.width=`${state.xp%100}%`;$("#level-message").textContent=level()>1?"Tu progresses super bien ! ✨":"Commence ton aventure !";
  const due=state.revisions.filter(isDue).sort((a,b)=>a.date.localeCompare(b.date)).slice(0,5);
  $("#today-revisions").innerHTML=due.length?due.map(r=>revisionHTML(r)).join(""):`<div class="empty-state"><div style="font-size:35px">🌷</div><strong>Tout est à jour !</strong><span>Aucune révision urgente.</span></div>`;
  const mats=[...state.materials].reverse().slice(0,4);$("#recent-materials").innerHTML=mats.length?mats.map(m=>`<div class="material-mini"><span>${typeIcon(m.type)}</span><div><strong>${esc(m.title)}</strong><small>${esc(subjectName(m.subjectId))}</small></div></div>`).join(""):`<div class="empty-state">Ajoute ton premier cours.</div>`;
  $("#dashboard-mastery").innerHTML=state.subjects.slice(0,5).map(s=>{let count=state.materials.filter(m=>m.subjectId===s.id).length;let pct=Math.min(100,count*20);return `<div class="mastery-row"><div><span>${s.icon} ${esc(s.name)}</span><span>${pct}%</span></div><div class="mastery-bar"><div style="width:${pct}%"></div></div></div>`}).join("")||`<div class="empty-state">Ajoute une matière.</div>`;
}
function revisionHTML(r){
  const m=state.materials.find(x=>x.id===r.materialId);return `<div class="revision-item"><div class="revision-dot"></div><div><strong>${esc(m?.title||"Cours supprimé")}</strong><small>${r.date===today()?"Aujourd'hui":dateLabel(r.date)} · Révision ${r.number}</small></div><button onclick="completeRevision('${r.id}')">${r.completed?"✓":"Réviser"}</button></div>`;
}
window.completeRevision=id=>{const r=state.revisions.find(x=>x.id===id);if(!r||r.completed)return;r.completed=true;state.xp+=20;state.streak=Math.max(1,state.streak);state.bestStreak=Math.max(state.bestStreak,state.streak);save();toast("+20 XP ✨");renderAll()};
function renderSubjects(){
  $("#subjects-grid").innerHTML=state.subjects.length?state.subjects.map(s=>`<article class="subject-card"><div class="subject-color" style="background:${s.color}"></div><div class="subject-icon">${s.icon}</div><h3>${esc(s.name)}</h3><p>${state.materials.filter(m=>m.subjectId===s.id).length} cours · ${state.revisions.filter(r=>state.materials.some(m=>m.id===r.materialId&&m.subjectId===s.id)).length} révisions</p><div class="subject-actions"><button class="small-button" onclick="viewSubject('${s.id}')">Voir</button><button class="small-button" onclick="deleteSubject('${s.id}')">Supprimer</button></div></article>`).join(""):`<div class="empty-state"><div style="font-size:45px">📚</div><strong>Aucune matière</strong><span>Crée ta première matière.</span></div>`;
}
window.viewSubject=id=>{navigate("materials");$("#material-subject-filter").value=id;renderMaterials()}
window.deleteSubject=id=>{if(!confirm("Supprimer cette matière et ses cours ?"))return;state.subjects=state.subjects.filter(s=>s.id!==id);const mids=state.materials.filter(m=>m.subjectId===id).map(m=>m.id);state.materials=state.materials.filter(m=>m.subjectId!==id);state.revisions=state.revisions.filter(r=>!mids.includes(r.materialId));save();renderAll();toast("Matière supprimée")}
function typeIcon(t){return t==="pdf"?"📄":t==="notes"?"📝":"📖"}
function renderMaterials(){
  const filter=$("#material-subject-filter").value||"all", type=$("#material-type-filter").value||"all", q=($("#material-search").value||"").toLowerCase();
  $("#material-subject-filter").innerHTML=`<option value="all">Toutes les matières</option>`+state.subjects.map(s=>`<option value="${s.id}">${s.icon} ${esc(s.name)}</option>`).join("");$("#material-subject-filter").value=filter;
  let arr=state.materials.filter(m=>(filter==="all"||m.subjectId===filter)&&(type==="all"||m.type===type)&&(!q||m.title.toLowerCase().includes(q)||m.content.toLowerCase().includes(q)));
  $("#materials-grid").innerHTML=arr.length?arr.map(m=>`<article class="material-card"><div class="material-icon">${typeIcon(m.type)}</div><h3>${esc(m.title)}</h3><p>${esc(subjectName(m.subjectId))}</p><div class="material-meta"><span>${m.content.length} caractères</span><span>${dateLabel(m.createdAt)}</span></div><div class="material-actions"><button class="small-button" onclick="openMaterial('${m.id}')">Ouvrir</button><button class="small-button" onclick="scheduleMaterial('${m.id}')">Réviser</button><button class="small-button" onclick="deleteMaterial('${m.id}')">Supprimer</button></div></article>`).join(""):`<div class="empty-state"><div style="font-size:45px">📄</div><strong>Aucun cours trouvé</strong><span>Ajoute un cours ou modifie tes filtres.</span></div>`;
}
window.openMaterial=id=>{const m=state.materials.find(x=>x.id===id);if(!m)return;openModal(`<span class="section-eyebrow">${typeIcon(m.type)} ${esc(subjectName(m.subjectId))}</span><h2>${esc(m.title)}</h2><div style="white-space:pre-wrap;line-height:1.7;color:#665f69">${esc(m.content)}</div><div style="margin-top:20px;display:flex;gap:8px"><button class="primary-button" onclick="scheduleMaterial('${id}');closeModal()">Programmer une révision</button><button class="secondary-button" onclick="startMaterialFlashcards('${id}');closeModal()">Flashcards</button></div>`)}
window.deleteMaterial=id=>{if(!confirm("Supprimer ce cours ?"))return;state.materials=state.materials.filter(m=>m.id!==id);state.revisions=state.revisions.filter(r=>r.materialId!==id);state.flashcards=state.flashcards.filter(f=>f.materialId!==id);save();renderAll();toast("Cours supprimé")}
window.scheduleMaterial=id=>{const d=new Date();d.setDate(d.getDate()+2);state.revisions.push({id:uid(),materialId:id,number:1,date:d.toISOString().slice(0,10),completed:false});save();renderAll();toast("Révision prévue dans 2 jours 📅")}
function renderRevisions(){
  const all=[...state.revisions].sort((a,b)=>a.date.localeCompare(b.date));const end=new Date();end.setDate(end.getDate()+7);const endS=end.toISOString().slice(0,10);
  $("#revision-today-count").textContent=all.filter(r=>r.date===today()&&!r.completed).length;$("#revision-upcoming-count").textContent=all.filter(r=>r.date>=today()&&r.date<=endS&&!r.completed).length;$("#revision-completed-count").textContent=all.filter(r=>r.completed).length;
  const groups={};all.forEach(r=>(groups[r.date]??=[]).push(r));$("#revision-full-list").innerHTML=Object.keys(groups).length?Object.keys(groups).map(d=>`<div class="revision-day"><div class="revision-day-title">${d===today()?"AUJOURD'HUI":dateLabel(d)}</div>${groups[d].map(revisionHTML).join("")}</div>`).join(""):`<div class="empty-state">Aucune révision programmée.</div>`;
}
let calDate=new Date(),selectedCal=today();
function renderCalendar(){
  $("#calendar-month").textContent=`${months[calDate.getMonth()]} ${calDate.getFullYear()}`;
  const first=new Date(calDate.getFullYear(),calDate.getMonth(),1), last=new Date(calDate.getFullYear(),calDate.getMonth()+1,0), offset=(first.getDay()+6)%7,total=Math.ceil((offset+last.getDate())/7)*7;
  let html="";for(let i=0;i<total;i++){const n=i-offset,d=new Date(calDate.getFullYear(),calDate.getMonth(),n),ds=d.toISOString().slice(0,10),outside=d.getMonth()!==calDate.getMonth(),has=state.revisions.some(r=>r.date===ds&&!r.completed);html+=`<button class="calendar-day ${outside?"muted":""} ${ds===today()?"today":""} ${ds===selectedCal?"selected":""}" onclick="selectCal('${ds}')"><span class="day-number">${d.getDate()}</span>${has?'<span class="event-dot"></span>':''}</button>`}
  $("#calendar-grid").innerHTML=html;selectCal(selectedCal,true);
}
window.selectCal=(d,silent=false)=>{selectedCal=d;const rs=state.revisions.filter(r=>r.date===d);$("#selected-date-title").textContent=d===today()?"Aujourd'hui":dateLabel(d);$("#selected-date-revisions").innerHTML=rs.length?rs.map(revisionHTML).join(""):`<div class="empty-state">Aucune révision ce jour.</div>`;if(!silent)renderCalendar()}
function renderFlashcards(){
  const decks={};state.flashcards.forEach(f=>(decks[f.materialId]??=[]).push(f));
  const keys=Object.keys(decks);$("#flashcard-decks").innerHTML=keys.length?keys.map(id=>`<div class="deck-card"><div style="font-size:30px">🃏</div><h3>${esc(materialName(id))}</h3><p>${decks[id].length} cartes</p><button class="primary-button" onclick="startDeck('${id}')">Réviser</button></div>`).join(""):`<div class="empty-state"><div style="font-size:45px">🃏</div><strong>Aucune flashcard</strong><span>Ajoute un cours puis crée un paquet.</span></div>`;
  $("#flashcard-area").innerHTML="";
}
let flashSession=[],flashIndex=0;
window.startDeck=id=>{flashSession=state.flashcards.filter(f=>f.materialId===id);flashIndex=0;renderFlashCard()}
window.startMaterialFlashcards=id=>{const fs=state.flashcards.filter(f=>f.materialId===id);if(fs.length)startDeck(id);else toast("Ce cours n'a pas encore de flashcards")}
function renderFlashCard(){if(!flashSession.length)return;$("#flashcard-area").innerHTML=`<div class="flashcard-study"><div class="flashcard-progress">Carte ${flashIndex+1} / ${flashSession.length}</div><div id="flashcard" class="flashcard"><div class="flashcard-inner"><div class="flash-face"><small>QUESTION</small><p>${esc(flashSession[flashIndex].question)}</p><small>Clique pour retourner</small></div><div class="flash-face flash-back"><small>RÉPONSE</small><p>${esc(flashSession[flashIndex].answer)}</p></div></div></div><div class="flash-actions"><button class="hard" onclick="flashRate()">😕 À revoir</button><button class="medium" onclick="flashRate()">🙂 Moyen</button><button class="easy" onclick="flashRate()">✨ Facile</button></div></div>`;$("#flashcard").onclick=()=>$("#flashcard").classList.toggle("flipped")}
window.flashRate=()=>{state.xp+=5;flashIndex++;save();if(flashIndex>=flashSession.length){toast("Paquet terminé ! +5 XP par carte ✨");flashSession=[];renderFlashcards()}else renderFlashCard();renderDashboard()}
function renderQuizOptions(){const cur=$("#quiz-subject").value||"all";$("#quiz-subject").innerHTML=`<option value="all">Toutes les matières</option>`+state.subjects.map(s=>`<option value="${s.id}">${s.icon} ${esc(s.name)}</option>`).join("");$("#quiz-subject").value=cur}
let quizSession=[],quizIndex=0,quizScore=0;
function makeQuestions(){
  let mats=state.materials.filter(m=>$("#quiz-subject").value==="all"||m.subjectId===$("#quiz-subject").value);
  if(!mats.length)return [];
  let qs=[];mats.forEach(m=>{qs.push({q:`Que peux-tu retenir de « ${m.title} » ?`,answers:[m.content.slice(0,90), "Aucune information importante","Un sujet sans rapport","Une date au hasard"],correct:0});qs.push({q:`Dans quelle matière se trouve « ${m.title} » ?`,answers:[subjectName(m.subjectId), "Mathématiques","Anglais","Histoire-Géo"],correct:0})});return qs;
}
function startQuiz(){quizSession=makeQuestions();if(!quizSession.length){toast("Ajoute au moins un cours.");return}const n=+$("#quiz-length").value;quizSession=quizSession.sort(()=>Math.random()-.5).slice(0,n);quizIndex=0;quizScore=0;$("#quiz-selection").classList.add("hidden");$("#quiz-area").classList.remove("hidden");renderQuestion()}
function renderQuestion(){const q=quizSession[quizIndex];$("#quiz-area").innerHTML=`<div class="quiz-top"><button class="text-button" onclick="quitQuiz()">← Quitter</button><div class="quiz-progress">${quizIndex+1} / ${quizSession.length}<div class="quiz-progress-bar"><div style="width:${(quizIndex+1)/quizSession.length*100}%"></div></div></div></div><div class="quiz-card"><span class="question-category">QUESTION ${quizIndex+1}</span><h2>${esc(q.q)}</h2><div>${q.answers.map((a,i)=>`<button class="quiz-answer" data-i="${i}">${esc(a)}</button>`).join("")}</div><button id="quiz-next" class="primary-button quiz-next hidden">Question suivante →</button></div>`;$$(".quiz-answer").forEach(b=>b.onclick=()=>answerQuiz(+b.dataset.i));$("#quiz-next").onclick=nextQuestion}
function answerQuiz(i){const q=quizSession[quizIndex];$$(".quiz-answer").forEach((b,j)=>{b.disabled=true;if(j===q.correct)b.classList.add("correct");if(j===i&&i!==q.correct)b.classList.add("wrong")});if(i===q.correct){quizScore++;state.xp+=10}$("#quiz-next").classList.remove("hidden");save()}
function nextQuestion(){quizIndex++;if(quizIndex>=quizSession.length){state.quizzes.push({date:today(),score:quizScore,total:quizSession.length});save();toast(`Quiz terminé : ${quizScore}/${quizSession.length} 🎉`);quitQuiz()}else renderQuestion()}
window.quitQuiz=()=>{$("#quiz-area").classList.add("hidden");$("#quiz-selection").classList.remove("hidden");renderAll()}
function liliReply(msg){const m=msg.toLowerCase();if(m.includes("révis")||m.includes("revision")){const n=state.revisions.filter(isDue).length;return n?`Tu as ${n} révision(s) à faire aujourd'hui. Commence par la plus ancienne, puis avance tranquillement. 🌷`:"Tu n'as aucune révision urgente aujourd'hui. Profite-en pour revoir un cours que tu trouves difficile ! ✨"}if(m.includes("organ"))return"Je te conseille de choisir 1 à 3 priorités pour aujourd'hui, puis de faire une session Focus. N'essaie pas de tout faire en même temps. 💕";if(m.includes("espac"))return"La répétition espacée consiste à revoir une notion plusieurs fois avec des intervalles qui s'allongent. Ici, on peut programmer des révisions à 2, 3, 5 puis 7 jours. 🧠";if(m.includes("bonjour")||m.includes("coucou"))return"Cou-cou 🌸 Je suis contente de te voir ! On avance petit à petit aujourd'hui ?";return"Je peux t'aider à organiser tes révisions, regarder ce que tu dois faire aujourd'hui ou t'expliquer comment fonctionne STUDY PLANNER. 🌷"}
function sendLili(msg){const box=$("#lili-messages");box.innerHTML+=`<div class="lili-message user"><div class="message-bubble">${esc(msg)}</div></div>`;setTimeout(()=>{box.innerHTML+=`<div class="lili-message assistant"><div class="message-avatar">🌸</div><div class="message-bubble">${esc(liliReply(msg))}</div></div>`;box.scrollTop=box.scrollHeight},250);box.scrollTop=box.scrollHeight}
let focusSeconds=1500,focusTimer=null;
function updateFocus(){const m=Math.floor(focusSeconds/60),s=focusSeconds%60;$("#focus-timer").textContent=`${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`}
function renderStats(){const q=state.quizzes.reduce((a,x)=>a+x.score,0),done=state.revisions.filter(r=>r.completed).length;$("#stats-total-xp").textContent=state.xp;$("#stats-best-streak").textContent=state.bestStreak;$("#stats-quizzes").textContent=state.quizzes.length;$("#stats-revisions").textContent=done;$("#subject-statistics").innerHTML=state.subjects.map(s=>{const mats=state.materials.filter(m=>m.subjectId===s.id).length;const rev=state.revisions.filter(r=>r.completed&&state.materials.find(m=>m.id===r.materialId)?.subjectId===s.id).length;return `<div class="mastery-row"><div><span>${s.icon} ${esc(s.name)}</span><span>${Math.min(100,mats*20+rev*5)}%</span></div><div class="mastery-bar"><div style="width:${Math.min(100,mats*20+rev*5)}%"></div></div></div>`}).join("")||"<div class='empty-state'>Aucune donnée.</div>";const levels=[["À découvrir",state.subjects.length],["En apprentissage",state.materials.length],["À renforcer",state.revisions.filter(r=>!r.completed).length],["Bien maîtrisé",state.revisions.filter(r=>r.completed).length],["Maîtrisé",Math.floor(state.xp/100)]];$("#mastery-statistics").innerHTML=levels.map(x=>`<div class="revision-item"><div class="revision-dot"></div><div><strong>${x[0]}</strong><small>${x[1]}</small></div></div>`).join("")}
function renderProfile(){const u=state.user||{};$("#profile-avatar").textContent=u.avatar||"🌸";$("#profile-display-name").textContent=u.displayName||"Élève";$("#profile-class").textContent=u.classLevel||"—";$("#profile-level").textContent=level();$("#profile-first-name").value=u.firstName||"";$("#profile-display-name-input").value=u.displayName||"";$("#profile-class-input").value=u.classLevel||"";$$("#profile-avatar-options .avatar-option").forEach(b=>b.classList.toggle("selected",b.dataset.avatar===(u.avatar||"🌸")))}
function renderAll(){renderDate();renderDashboard();renderPage($(".nav-item.active")?.dataset.page||"dashboard")}
function openAddSubject(){openModal(`<h2>Ajouter une matière 🌸</h2><form id="subject-form"><div class="form-group"><label>Nom</label><input id="new-subject-name" required placeholder="Ex : SVT"></div><div class="form-group"><label>Icône</label><select id="new-subject-icon">${subjectIcons.map(i=>`<option>${i}</option>`).join("")}</select></div><button class="primary-button">Ajouter</button></form>`);$("#subject-form").onsubmit=e=>{e.preventDefault();state.subjects.push({id:uid(),name:$("#new-subject-name").value.trim(),icon:$("#new-subject-icon").value,color:colors[state.subjects.length%colors.length],createdAt:today()});save();closeModal();renderAll();toast("Matière ajoutée 🌸")}}
function openAddMaterial(){if(!state.subjects.length){toast("Crée d'abord une matière.");navigate("subjects");return}openModal(`<h2>Ajouter un cours 📚</h2><form id="material-form"><div class="form-group"><label>Titre</label><input id="new-material-title" required placeholder="Ex : Chapitre 1"></div><div class="form-group"><label>Matière</label><select id="new-material-subject">${state.subjects.map(s=>`<option value="${s.id}">${s.icon} ${esc(s.name)}</option>`).join("")}</select></div><div class="form-group"><label>Type</label><select id="new-material-type"><option value="course">Cours</option><option value="notes">Notes</option><option value="pdf">PDF</option></select></div><div class="form-group"><label>Contenu</label><textarea id="new-material-content" rows="7" required placeholder="Colle ou écris ton cours ici..."></textarea></div><button class="primary-button">Ajouter le cours</button></form>`);$("#material-form").onsubmit=e=>{e.preventDefault();const m={id:uid(),title:$("#new-material-title").value.trim(),subjectId:$("#new-material-subject").value,type:$("#new-material-type").value,content:$("#new-material-content").value.trim(),createdAt:today()};state.materials.push(m);const d=new Date();d.setDate(d.getDate()+2);state.revisions.push({id:uid(),materialId:m.id,number:1,date:d.toISOString().slice(0,10),completed:false});save();closeModal();renderAll();toast("Cours ajouté + première révision prévue 📅")}}
function openAddFlashcards(){if(!state.materials.length){toast("Ajoute d'abord un cours.");navigate("materials");return}openModal(`<h2>Créer des flashcards 🃏</h2><form id="fc-form"><div class="form-group"><label>Cours</label><select id="fc-material">${state.materials.map(m=>`<option value="${m.id}">${esc(m.title)}</option>`).join("")}</select></div><div class="form-group"><label>Question</label><input id="fc-q" required></div><div class="form-group"><label>Réponse</label><textarea id="fc-a" rows="4" required></textarea></div><button class="primary-button">Ajouter la carte</button></form>`);$("#fc-form").onsubmit=e=>{e.preventDefault();state.flashcards.push({id:uid(),materialId:$("#fc-material").value,question:$("#fc-q").value,answer:$("#fc-a").value});save();closeModal();renderFlashcards();toast("Flashcard ajoutée 🃏")}}
function init(){
  $("#show-signup-button").onclick=()=>{$("#login-view").classList.add("hidden");$("#signup-view").classList.remove("hidden")};
  $("#show-login-button").onclick=()=>{$("#signup-view").classList.add("hidden");$("#login-view").classList.remove("hidden")};
  $("#demo-login-button").onclick=loginDemo;
  $$(".nav-item,[data-page='profile'],.link-button").forEach(b=>b.onclick=()=>navigate(b.dataset.page));
  $("#signup-form").onsubmit=e=>{e.preventDefault();state.user={firstName:$("#signup-first-name").value,displayName:$("#signup-display-name").value,age:+$("#signup-age").value,classLevel:$("#signup-class").value,birthdate:$("#signup-birthdate").value,email:$("#signup-email").value,avatar:$(".signup-avatars .selected")?.dataset.avatar||"🌸"};seedData();save();show("app");renderAll();toast("Bienvenue dans ton espace 🌸")};
  $("#login-form").onsubmit=e=>{e.preventDefault();if(!state.user){toast("Aucun compte local. Utilise la démo ou crée ton compte.");return}show("app");renderAll();toast("Bon retour 🌷")};
  $$(".signup-avatars .avatar-option").forEach(b=>b.onclick=()=>{$$(".signup-avatars .avatar-option").forEach(x=>x.classList.remove("selected"));b.classList.add("selected")});
  $$(".nav-item").forEach(b=>b.addEventListener("click",()=>{}));
  $("#add-subject-button").onclick=openAddSubject;$("#add-material-button").onclick=openAddMaterial;$("#create-flashcard-button").onclick=openAddFlashcards;
  $("#material-search").oninput=renderMaterials;$("#material-type-filter").onchange=renderMaterials;$("#material-subject-filter").onchange=renderMaterials;
  $("#calendar-prev").onclick=()=>{calDate.setMonth(calDate.getMonth()-1);renderCalendar()};$("#calendar-next").onclick=()=>{calDate.setMonth(calDate.getMonth()+1);renderCalendar()};
  $("#start-quiz-button").onclick=startQuiz;
  $("#lili-form").onsubmit=e=>{e.preventDefault();const v=$("#lili-input").value.trim();if(v){$("#lili-input").value="";sendLili(v)}};$$(".lili-suggestions button").forEach(b=>b.onclick=()=>sendLili(b.dataset.message));
  $("#focus-start").onclick=()=>{if(focusTimer){clearInterval(focusTimer);focusTimer=null;$("#focus-start").textContent="Reprendre";$("#focus-status").textContent="Pause";return}$("#focus-start").textContent="Pause";$("#focus-status").textContent="Concentre-toi 🌸";focusTimer=setInterval(()=>{focusSeconds--;updateFocus();if(focusSeconds<=0){clearInterval(focusTimer);focusTimer=null;state.focusSessions++;state.xp+=25;save();toast("Session terminée ! +25 XP 🎉");focusSeconds=1500;updateFocus();$("#focus-start").textContent="Commencer";$("#focus-status").textContent="Bravo !"}},1000)};
  $("#focus-reset").onclick=()=>{clearInterval(focusTimer);focusTimer=null;focusSeconds=1500;updateFocus();$("#focus-start").textContent="Commencer";$("#focus-status").textContent="Prêt(e) à commencer ?"};
  $$(".focus-presets button").forEach(b=>b.onclick=()=>{$$(".focus-presets button").forEach(x=>x.classList.remove("active"));b.classList.add("active");focusSeconds=+b.dataset.minutes*60;updateFocus()});
  $("#profile-form").onsubmit=e=>{e.preventDefault();Object.assign(state.user,{firstName:$("#profile-first-name").value,displayName:$("#profile-display-name-input").value,classLevel:$("#profile-class-input").value,avatar:$("#profile-avatar-options .selected")?.dataset.avatar||state.user.avatar});save();renderAll();toast("Profil enregistré 🌷")};
  $$("#profile-avatar-options .avatar-option").forEach(b=>b.onclick=()=>{$$("#profile-avatar-options .avatar-option").forEach(x=>x.classList.remove("selected"));b.classList.add("selected")});
  $("#logout-button").onclick=()=>{show("auth");$("#login-view").classList.remove("hidden");$("#signup-view").classList.add("hidden");toast("À bientôt 🌸")};
  $("#modal-close").onclick=closeModal;$("#modal-overlay").onclick=e=>{if(e.target.id==="modal-overlay")closeModal()};
  $("#mobile-menu-button").onclick=()=>$(".sidebar").classList.toggle("open");
  if(state.user){show("app");renderAll()}else show("auth");
}
document.addEventListener("DOMContentLoaded",init);
